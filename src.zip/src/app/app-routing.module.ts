import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { VerifyregComponent } from './verifyreg/verifyreg.component';

import { ForgotpwdComponent } from './forgotpwd/forgotpwd.component';
import { ResetpwdComponent } from './resetpwd/resetpwd.component';
import { CustomerInfoComponent } from './Customer/customer-info/customer-info.component';

import { CommonTemplateComponent } from './products/common-template/common-template.component';
//import { QuickQuoteComponent } from './products/PC/quick-quote/quick-quote.component';
//import { AddInfoComponent } from './products/PC/add-info/add-info.component';
import { QuickQuoteComponent } from './products/NPM/quick-quote/quick-quote.component';
import { AddInfoComponent } from './products/NPM/add-info/add-info.component';

const routes: Routes = [
  { path: '', redirectTo: '/products/quickquote', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  {
    path: 'products',component: CommonTemplateComponent, 
    children: [
    //  { path: '', redirectTo:'quickquote',pathMatch:'full' },
      { path: 'quickquote', component: QuickQuoteComponent },
      { path: 'addInfo', component: AddInfoComponent }
      
    ]
  },
  
  { path: 'register', component: RegisterComponent },
  { path: 'verifyRegister', component: VerifyregComponent },
  { path: 'forgotpwd', component: ForgotpwdComponent },
  { path: 'resetpwd/:user', component: ResetpwdComponent },
  { path: 'customer', component: CustomerInfoComponent },

  { path: '**', redirectTo: 'error', pathMatch: 'full' }



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
