import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { API_URL } from '../app.constants';
import { map } from 'rxjs/operators';
import { AUTHENTICATED_USER } from './authenticate.service';


@Injectable({
  providedIn: 'root'
})
export class ForgotpasswordService {

  constructor(private http: HttpClient) { }

  api_url = API_URL;



  searchAgentService(username) {
    console.log("Service call for agent search");
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'text/plain'
      })
    };
    const url = `${this.api_url}login/agentContactDetails`;
    //const data = JSON.stringify(agent);
    return this.http.post(url, "AGENT_CONTACT_TABLE_QUERY:" + username, { responseType: 'json' }).pipe((data => {
      return data;
    })
    );

  }



  resetPassword(username) {
    console.log("Service call for reset password");
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'text/plain'
      })
    };
    const url = `${this.api_url}login/forgotPassword`;
  
    return this.http.post<string>(url,  username,httpOptions).pipe((data => {
      return data;
    })
    );
  

  }

}