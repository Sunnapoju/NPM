
export interface AgentContact {
    email_id:string;
    phone_no:string;
    agent_id: string;
    
    }
    
    