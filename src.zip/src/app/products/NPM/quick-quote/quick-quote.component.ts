import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { Observable, observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { API_URL } from '../../../app.constants';
import NPMConstants from '../../../data/npm-constant.json';
import 'hammerjs';
import {coerceNumberProperty} from '@angular/cdk/coercion';

@Component({
  selector: 'app-quick-quote',
  templateUrl: './quick-quote.component.html',
  styleUrls: ['./quick-quote.component.css']
})
export class QuickQuoteComponent implements OnInit {

  tempIP=API_URL;
  filterValue: any;

  
  tempgenPolicyInfoSOABO = NPMConstants.policySOABO;
   
  //tempRelation=NPMConstants.policySOABO.genPolicyInfoSOABO.insuredSOABOList.policyCtSOABOList.policyCtAcceSOABOList.fieldValueMap.NIC_Relationship_With_Proposer_Benefit
  //tempRelation=NPMConstants.policySOABO.insuredSOABOList.
  //policyCtSOABOList.policyCtAcceSOABOList.NIC_Relationship_With_Proposer_Benefit
  
  constructor(private httpClient:HttpClient) { }

  ngOnInit() {
    this.onLoadGetCodeTables('DURATION_TABLE_QUERY:ZONE_TABLE_QUERY');
  }

  // Duration dropdown
  durationControl = new FormControl();
  durationFiltered: Observable<any[]>;
  durationObjArr: any;
  public duration;
  // Duration
	builddurationDropdown(tempObjArr: any) {
    this.durationFiltered = this.durationControl.valueChanges
      .pipe(
      startWith(''),
      map(tableObj => tableObj ? this._durationFilter(tableObj) : tempObjArr.slice())
      );
  }
  private _durationFilter(tempObj: any): any[] {
		try {
		  this.filterValue = tempObj.toLowerCase();
		} catch (e) {
		  this.filterValue = tempObj.value.toLowerCase();
		}
		return this.durationObjArr.filter(tableObj => tableObj.value.toLowerCase().indexOf(this.filterValue) === 0);
  }
  displayDuratinoFn(optionObj: any): any {
    return optionObj ? optionObj.value : optionObj;
  }
  setDuration(optionObj: any) {
    if (optionObj) {
      this.tempgenPolicyInfoSOABO.genPolicyInfoSOABO.fieldValueMap.BREEDTYPE = optionObj.id + '';
    }
  }

  //Premium Paying zone dropdown
  zoneControl = new FormControl();
  zoneFiltered : Observable<any[]>;
  zoneObjArr:any;
  

  //Premium Paying zone
  buildZoneDropdown(tempObj:any){
       this.zoneFiltered=this.zoneControl.valueChanges
        .pipe(
          startWith(''),
          map(tableObj=>tableObj ? this._zoneFilter(tableObj):tableObj.slice)
          );
  }
  private _zoneFilter(tempObj:any):any{
    try {
		  this.filterValue = tempObj.toLowerCase();
		} catch (e) {
		  this.filterValue = tempObj.value.toLowerCase();
		}
		return this.zoneObjArr.filter(tableObj => tableObj.value.toLowerCase().indexOf(this.filterValue) === 0);
  }
  displayZoneFn(optionObj: any): any {
    return optionObj ? optionObj.value : optionObj;
  }
  setZone(optionObj: any) {
    if (optionObj) {
      this.tempgenPolicyInfoSOABO.genPolicyInfoSOABO.fieldValueMap.NIC_City_DropList = optionObj.id + '';
    }
  }

//Adding Rows
  public relation: string;
  public dateOfBirth: string;
  public age: string;
  public showInsuredInfo:boolean = false;

  insuredInfo = [];

  insuredInfoJson = {
    relation: "",
    DateOfBirth: "",
    age: ""   
  }

  addInsuredInfo(){
    this.showInsuredInfo = true;
    this.insuredInfoJson.relation = this.relation;
    this.insuredInfoJson.DateOfBirth = this.dateOfBirth;
    this.insuredInfoJson.age = this.age;  
    this.insuredInfo.push(this.insuredInfoJson);
    console.log(this.insuredInfo);
    
    
  }
  onRemoveRow(id) {
    this.insuredInfo.splice(id, 1);                 
  }
  onEditRow(id){
    this.dateOfBirth = this.insuredInfo[id].DateOfBirth;
    this.age = this.insuredInfo[id].age; 
    this.relation = this.insuredInfo[id].relation;     
  }


  email = new FormControl('', [Validators.required, Validators.email]);
  getErrorMessage() {
      return this.email.hasError('required') ? 'You must enter a value' :
          this.email.hasError('email') ? 'Not a valid email' :
              '';
  }


  displayCommonFn(optionObj: any): any {
    return optionObj ? optionObj.value : optionObj;
  }




 // all controller call methods
 async onLoadGetCodeTables(tableNames: string) {
    await this.httpClient.post(this.tempIP + 'quote/codeTables', tableNames, { responseType: 'json' })
      .toPromise().then(
        data => {
          console.log('Response data ', data);
          const tempRespObjArr = data;
          const tempRespObj = tempRespObjArr[0];

          this.durationObjArr = tempRespObj.DURATION_TABLE_QUERY;
          this.builddurationDropdown(this.durationObjArr);

          this.zoneObjArr = tempRespObj.ZONE_TABLE_QUERY;
          this.buildZoneDropdown(this.zoneObjArr);
          
        },
        error => {
          console.log('Error', error);
        }
      );
  }


   getErrorMessageDuration() {
    return this.durationControl.hasError('required') ? 'Please select RTO Location' : '';
 }


   //Basic Sum Insured Slider
    autoTicks = false;
    disabled = false;
    min = 100000;
    max = 1000000;
    showTicks = false;
    step = 100000;
    bvalue = 0;  
    vertical = false;

    get tickInterval(): number | 'auto' {
      return this.showTicks ? (this.autoTicks ? 'auto' : this._tickInterval) : 0;
    }
    set tickInterval(bvalue) {
      this._tickInterval = coerceNumberProperty(bvalue);
    }
    private _tickInterval = 1;

    public illnessCheck:boolean=false;
    public outpatientCheck:boolean=false;

    
   

}
