export interface Customer {
    animal: string;
  name: string;
}

