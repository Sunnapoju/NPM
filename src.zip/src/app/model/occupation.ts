export interface Occupation {
    id:number;
    value:string;
    
}
