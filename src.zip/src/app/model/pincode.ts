export interface Pincode {
pincode:string
city:string
district: string
locality:string
state:string

}
