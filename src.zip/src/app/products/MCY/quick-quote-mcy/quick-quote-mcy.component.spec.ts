import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuickQuoteMCYComponent } from './quick-quote-mcy.component';

describe('QuickQuoteMCYComponent', () => {
  let component: QuickQuoteMCYComponent;
  let fixture: ComponentFixture<QuickQuoteMCYComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuickQuoteMCYComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuickQuoteMCYComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
