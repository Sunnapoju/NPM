
export interface Address {
pincode: number;
city_name: string;
district_name: string;
locality: string;
state_name: string;
Country:string;
city_id:number;
district_id:number;
state_id:number;
sl_no:number;
/*
city_id: 695001
city_name: "Thiruvananthapuram"
district_id: 42012
district_name: "Thiruvananthapuram"
locality: "Karumom"
pincode: 695002
state_id: 42
state_name: "Kerala"
*/
}

