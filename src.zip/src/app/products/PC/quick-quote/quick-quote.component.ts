import { Component, OnInit, Input } from '@angular/core';
import { FormControl, FormGroupDirective, NgForm, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import moment from 'moment';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { CommonServiceService } from '../../../services/common-service.service';
import { API_URL } from '../../../app.constants';
//import PCConstant from '../../data/pc-constant.json';
import PCConstant from '../../../data/pc-constant.json';
//import { AddInfoComponent } from '../add-info/add-info.component';



import 'hammerjs';

@Component({
    selector: 'app-quick-quote',
    templateUrl: './quick-quote.component.html',
    styleUrls: ['./quick-quote.component.css']
})
export class QuickQuoteComponent implements OnInit {


    // childmessage : string = "I am passed from Parent to child component";
    //@Input() greetMessage: string = "I am passed from Parent to child component";


    selected: any = '';
    addinf: any;
    json: any = PCConstant;
    planObject = PCConstant.planArray;
    tempPortalServiceInputObj = PCConstant.portalServiceInputObj;
    tempPolicyBODynObjListArr = PCConstant.policyBODynObjListArr;
    tempInsuredBODynObjListArr = PCConstant.insuredBODynObjListArr;
    tempInsuredBOFieldValueMap = PCConstant.insuredBOFieldValueMap;
    tOdPolicyCtSOABOListObj = PCConstant.odPolicyCtSOABOListObj;
    tOdOdPolicyCtAcceSOABOListObj = PCConstant.odOdPolicyCtAcceSOABOListObj;
    telecOdPolicyCtAcceSOABOListObj = PCConstant.elecOdPolicyCtAcceSOABOListObj;
    tTpPolicyCtSOABOListObj = PCConstant.tpPolicyCtSOABOListObj;
    tTpbiTpPolicyCtAcceSOABOList = PCConstant.tpbiTpPolicyCtAcceSOABOList;
    tTppdTpPolicyCtSOABOListObj = PCConstant.tppdTpPolicyCtSOABOListObj;

    tInvoicePolicyCtSOABOListObj: any;
    tEnginePolicyCtSOABOListObj: any;

    tempPolicySOABO = PCConstant.policySOABO;
    tempInsuredSOABOListObj = PCConstant.insuredSOABOListObj;
    tempGenPolicyInfoSOABOObj = PCConstant.genPolicyInfoSOABOObj;
    tempVehicleInsuredSOABOObj = PCConstant.vehicleInsuredSOABOObj;
    tempNicPolicyCustSOABOObj = PCConstant.nicPolicyCustSOABOObj;

    tDiscPolicyDiscSOABOListObj = PCConstant.discPolicyDiscSOABOListObj;
    tLoadPolicyDiscSOABOListObj = PCConstant.loadPolicyDiscSOABOListObj;
    tPolicyPaymentSOABOObj = PCConstant.policyPaymentSOABOObj;

    // make dropdown
    makeControl = new FormControl();
    makeFiltered: Observable<any[]>;
    makeObjArr: any;
    // model dropdown
    modelControl = new FormControl();
    modelFiltered: Observable<any[]>;
    modelObjArr: any;
    // variant dropdown
    variantControl = new FormControl();
    variantFiltered: Observable<any[]>;
    variantObjArr: any;
    // rto dropdown
    rtoControl = new FormControl();
    rtoFiltered: Observable<any[]>;
    rtoObjArr: any;
    rtoSelectedObj: any;

    orginalEffectiveDate: any;
    policyEffectiveDate: any;
    policyExpiryDate: any;
    policyLiabilityExpDate: any;
    commonDateFormat = moment.HTML5_FMT.DATETIME_LOCAL_SECONDS;
    dateFormatAppend = '+05:30';
    vehicleAge: any;



    quickQuoteForm = {
        engineCover: '2',
        paOwnerDriver: '2',
        invoiceCover: '2',
        dateOfDelPurchase: new Date(),
        defaultEffectDate: new Date() // later get it from UI
    };

    title = 'NIC-Lite';
 tempIP=API_URL;
      //   tempIP = 'http://localhost:8080/';
    // tempIP = '';
    responseJsonObj2 = { quoteResult: { app: '', quoteNo: '', autoUwMsg: '', proposalStatus: '' }, saveQuoteIds: { policyId: '', payInfoId: '', insuredId: '' } };

    responseJsonObj = { app: '', quoteNo: '', autoUwMsg: '' };
    responseJsonObj1 = {};

    
    filterValue: any;

    // , private datePipe: DatePipe
    constructor(private router: Router, private httpClient: HttpClient, private spinner: NgxSpinnerService, private cs: CommonServiceService) { }

    ngOnInit() {

        this.tempInsuredSOABOListObj.planId = 700015907;
        this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_CIF_Gross_Premium_of_CIF_Policy = '0';

        this.onLoadGetCodeTables('MAKE_TABLE_QUERY:RTOCODE_TABLE_QUERY');
    }

    // auto populate related specific codes
    // Make
    buildMakeDropdown(tempObjArr: any) {
        this.makeFiltered = this.makeControl.valueChanges
            .pipe(
                startWith(''),
                map(tableObj => tableObj ? this._makeFilter(tableObj) : tempObjArr.slice())
            );
    }
    private _makeFilter(tempObj: any): any[] {
        try {
            this.filterValue = tempObj.toLowerCase();
        } catch (e) {
            this.filterValue = tempObj.value.toLowerCase();
        }
        return this.makeObjArr.filter(tableObj => tableObj.value.toLowerCase().indexOf(this.filterValue) === 0);
    }
    displayCommonFn(optionObj: any): any {
        return optionObj ? optionObj.value : optionObj;
    }
    loadModelCodTab(optionObj: any) {
        if (optionObj) {
            this.tempInsuredBOFieldValueMap.NICVehicleMake = optionObj.id + '';
            this.getModelRVariantCodTab('MODEL_TABLE_QUERY:' + optionObj.id, 'MODEL');
        }
    }
    // RTO
    buildRtoDropdown(tempObjArr: any) {
        this.rtoFiltered = this.rtoControl.valueChanges
            .pipe(
                startWith(''),
                map(tableObj => tableObj ? this._rtoFilter(tableObj) : tempObjArr.slice())
            );
    }
    private _rtoFilter(tempObj: any): any[] {
        try {
            this.filterValue = tempObj.toLowerCase();
        } catch (e) {
            this.filterValue = tempObj.value.toLowerCase();
        }
        return this.rtoObjArr.filter(tableObj => tableObj.value.toLowerCase().indexOf(this.filterValue) === 0);
    }
    setRtoObj(optionObj: any) {
        if (optionObj) {
            this.rtoSelectedObj = optionObj;
            this.tempInsuredBOFieldValueMap.RegisteringAuthorityCodeName = optionObj.id.split('_')[0];
        }
    }
    // Model
    buildModelDropdown(tempObjArr: any) {
        this.modelFiltered = this.modelControl.valueChanges
            .pipe(
                startWith(''),
                map(tableObj => tableObj ? this._modelFilter(tableObj) : tempObjArr.slice())
            );
    }
    private _modelFilter(tempObj: any): any[] {
        try {
            this.filterValue = tempObj.toLowerCase();
        } catch (e) {
            this.filterValue = tempObj.value.toLowerCase();
        }
        return this.modelObjArr.filter(tableObj => tableObj.value.toLowerCase().indexOf(this.filterValue) === 0);
    }
    loadVariantCodTab(optionObj: any) {
        if (optionObj) {
            this.tempInsuredBOFieldValueMap.NICVehicleModel = optionObj.id + '';
            this.getModelRVariantCodTab('VARIANT_TABLE_QUERY:' + optionObj.id, 'VARIANT');
        }
    }

    // variant
    buildVariantDropdown(tempObjArr: any) {
        console.log('Response varrr fromWhich ', tempObjArr);
        this.variantFiltered = this.variantControl.valueChanges
            .pipe(
                startWith(''),
                map(tableObj => tableObj ? this._variantFilter(tableObj) : tempObjArr.slice())
            );
    }
    private _variantFilter(tempObj: any): any[] {
        try {
            this.filterValue = tempObj.toLowerCase();
        } catch (e) {
            this.filterValue = tempObj.value.toLowerCase();
        }
        return this.variantObjArr.filter(tableObj => tableObj.value.toLowerCase().indexOf(this.filterValue) === 0);
    }
    setIdvAutopopulate(optionObj: any) {
        if (optionObj) {
            this.tempInsuredBOFieldValueMap.Variant = optionObj.id.split('_')[0] + '';
            console.log('varinatdddd : ', optionObj);
            this.getIdvAutopopulate(optionObj.id.split('_')[1] + ':' + this.rtoSelectedObj.id.split('_')[1]);
        }
    }

    // all required business logic methods
    setPolicyEffectiveDate() {
        this.orginalEffectiveDate = moment(this.quickQuoteForm.defaultEffectDate).format(this.commonDateFormat);
    }
    preparePolicyDates() {
        this.setPolicyEffectiveDate();
        console.log(this.orginalEffectiveDate);
        this.policyEffectiveDate = this.orginalEffectiveDate + this.dateFormatAppend;
        console.log(this.policyEffectiveDate);
        const effDate = this.quickQuoteForm.defaultEffectDate;
        if (this.tempInsuredSOABOListObj.planId === 700015907) {
            const expiryDate = new Date(effDate.getFullYear() + 1, effDate.getMonth(), effDate.getDate() - 1);
            expiryDate.setHours(23);
            expiryDate.setMinutes(59);
            expiryDate.setSeconds(59);
            const momentExpDate = moment(expiryDate).format(this.commonDateFormat);
            this.policyExpiryDate = momentExpDate + this.dateFormatAppend;
            console.log(this.policyExpiryDate);
            const lExpiryDate = new Date(effDate.getFullYear() + 3, effDate.getMonth(), effDate.getDate() - 1);
            lExpiryDate.setHours(23);
            lExpiryDate.setMinutes(59);
            lExpiryDate.setSeconds(59);
            this.policyLiabilityExpDate = Date.parse(lExpiryDate + '') + '';
            console.log(this.policyLiabilityExpDate);
            this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_Declaration_Date = this.policyLiabilityExpDate;
        }
    }
    prepareVehicleAge() {
        const regDate = this.quickQuoteForm.dateOfDelPurchase;
        console.log(regDate);
        this.vehicleAge = this.getDiffYears(regDate, this.orginalEffectiveDate);
        console.log(this.vehicleAge);
    }
    getIDVAmount(idvResponseArr: any): any {

        const monthDiff = this.getDiffMonths(this.quickQuoteForm.dateOfDelPurchase, this.quickQuoteForm.defaultEffectDate);
        let idvValue: any = 0;
        if (monthDiff <= 6) {
            idvValue = idvResponseArr[0];
        } else if (monthDiff > 6 && monthDiff <= 12) {
            idvValue = idvResponseArr[1];
        } else {
            // needs to cross verify the 10 years
            const vehYear = Math.ceil(monthDiff / 12) + 1; // + one for index
            if (vehYear <= 11) {
                idvValue = idvResponseArr[vehYear];
            }
        }
        return idvValue;
    }
    framePortalServiceInput() {

        this.preparePolicyDates();
        this.prepareVehicleAge();

        const tempVar: any = this.quickQuoteForm.dateOfDelPurchase;
        // use this must validate b4 parse here
        this.tempInsuredBOFieldValueMap.DateOfDeliveryPurchase = Date.parse(tempVar) + '';
        // this.tempInsuredBOFieldValueMap.YearOfManufacture = this.datePipe.transform(this.tempVar, 'yyyy') + '';
        this.tempVehicleInsuredSOABOObj.registrationNumber = this.tempVehicleInsuredSOABOObj.vehicleRegisterNo;
        this.tOdPolicyCtSOABOListObj.insuredId = this.responseJsonObj2.saveQuoteIds.insuredId;

        this.tEnginePolicyCtSOABOListObj = PCConstant.enginePolicyCtSOABOListObj;
        this.tInvoicePolicyCtSOABOListObj = PCConstant.invoicePolicyCtSOABOListObj;
        // basic mandatory benefit
        this.tOdPolicyCtSOABOListObj.policyCtAcceSOABOList = [];
        this.tOdPolicyCtSOABOListObj.policyCtAcceSOABOList.push(this.tOdOdPolicyCtAcceSOABOListObj);
        // push into cover
        for (let [key, value] of Object.entries(this.responseJsonObj2.saveQuoteIds)) {
            let keyvalue: any = key;
            if (keyvalue == this.tOdPolicyCtSOABOListObj.coverTypeId) {

                this.tOdPolicyCtSOABOListObj.policyCtId = value;
            } else if (keyvalue == this.tTpPolicyCtSOABOListObj.coverTypeId) {

                this.tTpPolicyCtSOABOListObj.policyCtId = value;
            } else if (this.quickQuoteForm.engineCover === '1' && keyvalue == this.tInvoicePolicyCtSOABOListObj.coverTypeId) {

                this.tInvoicePolicyCtSOABOListObj.policyCtId = value;

            } else if (keyvalue == this.tEnginePolicyCtSOABOListObj.coverTypeId) {

                this.tEnginePolicyCtSOABOListObj.policyCtId = value;
            }
        }


        this.tempInsuredSOABOListObj.policyCtSOABOList = [];
        this.tempInsuredSOABOListObj.policyCtSOABOList.push(this.tOdPolicyCtSOABOListObj);

        this.tTpPolicyCtSOABOListObj.effectiveDate = this.policyEffectiveDate;
        this.tTpPolicyCtSOABOListObj.expirtyDate = this.policyExpiryDate;
        this.tTpPolicyCtSOABOListObj.policyCtAcceSOABOList = [];
        this.tTpPolicyCtSOABOListObj.policyCtAcceSOABOList.push(this.tTpbiTpPolicyCtAcceSOABOList);
        this.tTpPolicyCtSOABOListObj.policyCtAcceSOABOList.push(this.tTppdTpPolicyCtSOABOListObj);
        // push into cover
        this.tempInsuredSOABOListObj.policyCtSOABOList.push(this.tTpPolicyCtSOABOListObj);
        // option covers
        if (this.quickQuoteForm.invoiceCover === '1') {
            this.tInvoicePolicyCtSOABOListObj = PCConstant.invoicePolicyCtSOABOListObj;
            this.tInvoicePolicyCtSOABOListObj.effectiveDate = this.policyEffectiveDate;
            this.tInvoicePolicyCtSOABOListObj.expirtyDate = this.policyExpiryDate;
            this.tInvoicePolicyCtSOABOListObj.fieldValueMap.BasicIDV = this.tOdOdPolicyCtAcceSOABOListObj.interestSi;
            // push into cover
            this.tempInsuredSOABOListObj.policyCtSOABOList.push(this.tInvoicePolicyCtSOABOListObj);
        }
        if (this.quickQuoteForm.engineCover === '1') {
            this.tEnginePolicyCtSOABOListObj = PCConstant.enginePolicyCtSOABOListObj;
            this.tEnginePolicyCtSOABOListObj.effectiveDate = this.policyEffectiveDate;
            this.tEnginePolicyCtSOABOListObj.expirtyDate = this.policyExpiryDate;
            // here needs to set age of vehicle in agreed field
            this.tEnginePolicyCtSOABOListObj.fieldValueMap.AgreedValue = this.vehicleAge + '';
            // push into cover
            this.tempInsuredSOABOListObj.policyCtSOABOList.push(this.tEnginePolicyCtSOABOListObj);
        }
        this.tOdPolicyCtSOABOListObj.policyCtAcceSOABOList.push(this.telecOdPolicyCtAcceSOABOListObj);

        this.tempInsuredSOABOListObj.effectiveDate = this.policyEffectiveDate;
        this.tempInsuredSOABOListObj.expiryDate = this.policyExpiryDate;
        this.tempInsuredSOABOListObj.policyId = this.responseJsonObj2.saveQuoteIds.policyId;
        this.tempInsuredSOABOListObj.insuredId = this.responseJsonObj2.saveQuoteIds.insuredId;
        this.tempInsuredSOABOListObj.vehicleInsuredSOABO = this.tempVehicleInsuredSOABOObj;
        this.tempInsuredSOABOListObj.dynamicObjectList = this.tempInsuredBODynObjListArr;
        this.tempInsuredSOABOListObj.fieldValueMap = this.tempInsuredBOFieldValueMap;

        this.tempPolicySOABO.effectDate = this.policyEffectiveDate;
        this.tempPolicySOABO.expiryDate = this.policyExpiryDate;
        this.tempPolicySOABO.quotationNumber = this.responseJsonObj2.quoteResult.quoteNo;
        this.tempPolicySOABO.proposalStatus = this.responseJsonObj2.quoteResult.proposalStatus;
        this.tempPolicySOABO.policyId = this.responseJsonObj2.saveQuoteIds.policyId;


        this.tempPolicySOABO.dynamicObjectList = this.tempPolicyBODynObjListArr;
        this.tempGenPolicyInfoSOABOObj.policyId = this.responseJsonObj2.saveQuoteIds.policyId;
        this.tempPolicySOABO.genPolicyInfoSOABO = this.tempGenPolicyInfoSOABOObj;
        this.tempPolicySOABO.insuredSOABOList = [];
        this.tempPolicySOABO.insuredSOABOList.push(this.tempInsuredSOABOListObj);
        this.tempNicPolicyCustSOABOObj.policyId = this.responseJsonObj2.saveQuoteIds.policyId;
        this.tempPolicySOABO.nicPolicyCustSOABO = this.tempNicPolicyCustSOABOObj;
        this.tempPolicySOABO.policyDiscSOABOList = [];
        this.tDiscPolicyDiscSOABOListObj.policyId = this.responseJsonObj2.saveQuoteIds.policyId;
        this.tempPolicySOABO.policyDiscSOABOList.push(this.tDiscPolicyDiscSOABOListObj);
        this.tLoadPolicyDiscSOABOListObj.policyId = this.responseJsonObj2.saveQuoteIds.policyId;
        this.tempPolicySOABO.policyDiscSOABOList.push(this.tLoadPolicyDiscSOABOListObj);
        this.tPolicyPaymentSOABOObj.policyPayInfoSOABOList[0].payInfoId = this.responseJsonObj2.saveQuoteIds.payInfoId;
        this.tPolicyPaymentSOABOObj.policyPayInfoSOABOList[0].policyId = this.responseJsonObj2.saveQuoteIds.policyId;
        this.tempPolicySOABO.policyPaymentSOABO = this.tPolicyPaymentSOABOObj;

        this.tempPortalServiceInputObj.policySOABO = this.tempPolicySOABO;
        console.log('Final Prepared Object :  ', this.tempPortalServiceInputObj);
    }

    setLoadQuoteData(loadQObj: any) {
        console.log('responseJsonObj1.quoteNo', loadQObj);
        this.tempGenPolicyInfoSOABOObj = loadQObj.genPolicyInfoSOABO;
        console.log(this.tempGenPolicyInfoSOABOObj);
        this.tempVehicleInsuredSOABOObj = loadQObj.insuredSOABOList[0].vehicleInsuredSOABO;
        //this.tempInsuredBOFieldValueMap = loadQObj.insuredSOABOList[0].fieldValueMap;
        this.tempNicPolicyCustSOABOObj = loadQObj.nicPolicyCustSOABO;
        this.tPolicyPaymentSOABOObj = loadQObj.policyPaymentSOABO;

        // iterate the discount list and set into appropriate discount type object...
        let tempList = loadQObj.policyDiscSOABOList;
        for (let discObj of tempList) {
            if (discObj.discountType === "105") {
                this.tDiscPolicyDiscSOABOListObj = discObj;
            } else if (discObj.discountType === "91") {
                this.tLoadPolicyDiscSOABOListObj = discObj;
            }
        }
        this.tempInsuredSOABOListObj = loadQObj.insuredSOABOList[0];
        console.log(this.tempInsuredSOABOListObj);

        this.tempInsuredBOFieldValueMap = loadQObj.insuredSOABOList[0].fieldValueMap;

        tempList = this.tempInsuredSOABOListObj.policyCtSOABOList;

        for (let ctObj of tempList) {
            if (ctObj.coverType === 700000500) {
                this.tOdPolicyCtSOABOListObj = ctObj;
            } else if (ctObj.coverType === 700001243) {
                this.tTpPolicyCtSOABOListObj = ctObj;
            }
        }

        tempList = this.tOdPolicyCtSOABOListObj.policyCtAcceSOABOList;

        for (let ctAccObj of tempList) {
            if (ctAccObj.interestType === 700000120) {
                this.tOdOdPolicyCtAcceSOABOListObj = ctAccObj;
            } else if (ctAccObj.interestType === 100000060) {
                this.telecOdPolicyCtAcceSOABOListObj = ctAccObj;
            }
        }

        tempList = this.tTpPolicyCtSOABOListObj.policyCtAcceSOABOList;

        for (let ctAccObj of tempList) {
            if (ctAccObj.interestType === 100000040) {
                this.tTpbiTpPolicyCtAcceSOABOList = ctAccObj;
            } else if (ctAccObj.interestType === 100000041) {
                this.tTppdTpPolicyCtSOABOListObj = ctAccObj;
            }
        }

    }

    // all controller call methods
    async onLoadGetCodeTables(tableNames: string) {
        await this.httpClient.post(this.tempIP + 'quote/codeTables', tableNames, { responseType: 'json' })
            .toPromise().then(
                data => {
                    console.log('Response data ', data);
                    const tempRespObjArr = data;
                    const tempRespObj = tempRespObjArr[0];

                    this.makeObjArr = tempRespObj.MAKE_TABLE_QUERY;
                    this.buildMakeDropdown(this.makeObjArr);
                    this.rtoObjArr = tempRespObj.RTOCODE_TABLE_QUERY;
                    this.buildRtoDropdown(this.rtoObjArr);
                },
                error => {
                    console.log('Error', error);
                }
            );
    }
    async getModelRVariantCodTab(tableCodeName: string, fromWhere: string) {
        await this.httpClient.post(this.tempIP + 'quote/codeTableByCode', tableCodeName, { responseType: 'json' })
            .toPromise().then(
                data => {
                    console.log('Response ddd data ', data);
                    if (fromWhere === 'MODEL') {
                        this.modelObjArr = data;
                        this.buildModelDropdown(this.modelObjArr);
                    } else {
                        this.variantObjArr = data;
                        this.buildVariantDropdown(this.variantObjArr);
                    }
                },
                error => {
                    console.log('Error', error);
                }
            );
    }
    async getIdvAutopopulate(variantStateId: string) {
        await this.httpClient.post(this.tempIP + 'quote/idvAutoPopulate', variantStateId, { responseType: 'text' })
            .toPromise().then(
                data => {
                    console.log('Response ddd data ', data);
                    const idvAutoPopulateArr = (data.split('~~')[0]).split('~');
                    this.tempInsuredBOFieldValueMap.TypeOfBody = idvAutoPopulateArr[5] + '';
                    this.tempInsuredBOFieldValueMap.TypeOfFuel = idvAutoPopulateArr[6] + '';
                    this.tempInsuredBOFieldValueMap.NIC_PC_Cubic_Capacity = idvAutoPopulateArr[1] + '';
                    this.tempVehicleInsuredSOABOObj.numberofSeats = idvAutoPopulateArr[0];
                    this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_CIF_Sum_Insured = idvAutoPopulateArr[2] + '';
                    this.tempInsuredBOFieldValueMap.YearOfManufacture = idvAutoPopulateArr[3] + '';

                    const idvValAutoPopulateArr = (data.split('~~')[1]).split('~');
                    const idvValue = this.getIDVAmount(idvValAutoPopulateArr);
                    const idvValueStr = idvValue + '';
                    console.log('idvValueStr' + idvValueStr);
                    this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_CIF_Gross_Premium_of_CIF_Policy = idvValueStr;
                    this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_Volume_Discount = idvValueStr;

                    this.tOdOdPolicyCtAcceSOABOListObj.fieldValueMap.NIC_FestivalSumInsured_Benefit = idvValueStr;
                    this.tOdOdPolicyCtAcceSOABOListObj.interestSi = idvValue;
                    this.tOdOdPolicyCtAcceSOABOListObj.fieldValueMap.IManufacturerSellingPrice = idvAutoPopulateArr[2] + '';
                    this.tOdPolicyCtSOABOListObj.fieldValueMap.NIC_Deductible3 = idvValueStr;
                },
                error => {
                    console.log('Error', error);
                }
            );
    }
    tempCommonJson = {
        quoteNo: "",
        permium: "",
        idv: "",


    }
    saveQuickQuote() {

        this.spinner.show();

        this.framePortalServiceInput();
        this.httpClient.post(this.tempIP + 'quote/saveQuote',
            JSON.stringify(this.tempPortalServiceInputObj),
            { responseType: 'json' })
            .subscribe(
                data => {
                    console.log('POST Request is successful ', data);
                    const responseJson = data[0];
                    this.responseJsonObj2 = JSON.parse(responseJson);
                    console.log('responseJsonObj.quoteNo', this.responseJsonObj2);
                    sessionStorage.setItem('appinf', JSON.stringify(this.responseJsonObj2));
                    console.log(this.responseJsonObj2.quoteResult.quoteNo);
                    this.tempCommonJson.quoteNo=this.responseJsonObj2.quoteResult.quoteNo;
                    this.tempCommonJson.permium = this.responseJsonObj2.quoteResult.app;
                    this.tempCommonJson.idv = this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_CIF_Gross_Premium_of_CIF_Policy
                    this.cs.common.next(this.tempCommonJson);
                },
                error => {
                    console.log('Error', error);
                }
            );
        setTimeout(() => {
            /** spinner ends after 5 seconds */
            this.spinner.hide();
        }, 10000);
    }
    invoice: number = 0;
    invoiceprotect(value) {
        if (value.checked == true) {
            this.invoice = 1;
            this.quickQuoteForm.invoiceCover = '1';
        } else {
            this.invoice = 0;
            this.quickQuoteForm.invoiceCover = '0'
        }
    }

    engine: number = 0;

    engineprotect(value) {
        if (value.checked == true) {
            this.engine = 1;
            this.quickQuoteForm.engineCover = '1';
        } else {
            this.engine = 0;
            this.quickQuoteForm.engineCover = '0';
        }
    }
    percentagevalue: number;
    percentcal: number;
    percentage() {
        if (this.percentcal == 1) {
            this.tDiscPolicyDiscSOABOListObj.discountRate = this.percentagevalue;
            console.log('discount ', this.percentcal);
        } else {

            this.tLoadPolicyDiscSOABOListObj.discountRate = this.percentagevalue;
            console.log('loading ', this.percentcal);
        }
    }



    loadQuoteByQuote() {
        this.httpClient.post(this.tempIP + 'quote/loadQuote', this.responseJsonObj.quoteNo, { responseType: 'json' })
            .subscribe(
                data => {
                    console.log('POST Request is successful ', data);

                    const responseJson1 = data[0];
                    this.responseJsonObj1 = JSON.parse(responseJson1);
                    //   this.setLoadQuoteData(this.responseJsonObj1);
                    //    this.addinf=JSON.stringify(this.tempPortalServiceInputObj);
                    //         this.router.navigate(['addInfo',this.addinf]);   
                },
                error => {
                    console.log('Error', error);
                }
            );
    }

    passaddinf() {


        console.log('success', this.responseJsonObj2.quoteResult.quoteNo);
        sessionStorage.setItem('addinf', JSON.stringify(this.responseJsonObj2));
        sessionStorage.setItem('portalform', JSON.stringify(this.tempPortalServiceInputObj));
        //  this.router.navigate(['addInfo',this.responseJsonObj2.quoteResult.quoteNo]);  
        this.router.navigateByUrl("/products/addInfo");
    }

    // all date convertion methods
    getDiffDays(startdate: Date, enddate: Date): any {
        // define moments for the startdate and enddate
        const startdateMoment = moment(startdate);
        const enddateMoment = moment(enddate);
        if (startdateMoment.isValid() === true && enddateMoment.isValid() === true) {
            // getting the difference in days
            return enddateMoment.diff(startdateMoment, 'days');
        }
        return undefined;
    }
    getDiffMonths(startdate: Date, enddate: Date): any {
        // define moments for the startdate and enddate
        const startdateMoment = moment(startdate);
        const enddateMoment = moment(enddate);
        if (startdateMoment.isValid() === true && enddateMoment.isValid() === true) {
            const years = enddateMoment.diff(startdateMoment, 'years');
            // getting the difference in months
            return enddateMoment.diff(startdateMoment, 'months') - (years * 12);
        }
        return undefined;
    }
    getDiffYears(startdate: Date, enddate: Date): any {
        // define moments for the startdate and enddate
        const startdateMoment = moment(startdate);
        const enddateMoment = moment(enddate);
        if (startdateMoment.isValid() === true && enddateMoment.isValid() === true) {
            // getting the difference in years
            return enddateMoment.diff(startdateMoment, 'years');
        }
        return undefined;
    }
    dateDiff(startdate: Date, enddate: Date): any {
        // define moments for the startdate and enddate
        const startdateMoment = moment(startdate);
        const enddateMoment = moment(enddate);

        if (startdateMoment.isValid() === true && enddateMoment.isValid() === true) {
            // getting the difference in years
            const years = enddateMoment.diff(startdateMoment, 'years');
            // moment returns the total months between the two dates, subtracting the years
            const months = enddateMoment.diff(startdateMoment, 'months') - (years * 12);
            // to calculate the days, first get the previous month and then subtract it
            startdateMoment.add(years, 'years').add(months, 'months');
            const days = enddateMoment.diff(startdateMoment, 'days');
            console.log(years + ' months ' + months + ' days ' + days);
        }
    }

    email = new FormControl('', [Validators.required, Validators.email]);
    //    rtoControl = new FormControl();
    //  this.rtoControl = new FormControl('', [Validators.required]);
    getErrorMessage() {
        return this.email.hasError('required') ? 'You must enter a value' :
            this.email.hasError('email') ? 'Not a valid email' :
                '';
    }

    getErrorMessageRTOLoc() {
        return this.rtoControl.hasError('required') ? 'Please select RTO Location' : '';

    }
    getErrorMessageMake() {
        return this.makeControl.hasError('required') ? 'Please select Make' : '';

    }
    getErrorMessageModel() {
        return this.modelControl.hasError('required') ? 'Please select Model' : '';

    }
   getErrorMessageVariant() {
        return this.variantControl.hasError('required') ? 'Please select Varient' : '';

    }




    /*
      getErrorMessage() {
          if (this.email.hasError('required')) {
              return 'You must enter a value';
  
          } else if (this.email.hasError('email')) {
              return 'Not a valid email';
          }
           else if (this.rtoControl.hasError('rtoControl')) {
              return 'Please select RTO Location';
          }
  
      }
  
  */




}
